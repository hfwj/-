"""Generate standalone PSpice-style circuits and a 17-pin Multisim import model.
No Windows Multisim native schematic is generated. Assumptions are in README.
"""
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MODEL=r'''* G problem / synchronous Buck Rev B / FUNCTIONAL EQUIVALENT
* PSpice-style E/G VALUE expressions; NOT manufacturer IR2104/IRF540/INA models.
* COM must be connected to global SPICE ground 0.
* Pins: VIN_EXT VOUT VSET ISET ARM MCU_EN FAULT_N IL_BI ADC_IL
*       ADC_VIN ADC_IIN ADC_VOUT ADC_IOUT GH_MON GL_MON BOOT_MON COM
.SUBCKT GBUCK_REVB_EQ VIN_EXT VOUT VSET ISET ARM MCU_EN FAULT_N IL_BI ADC_IL
+ ADC_VIN ADC_IIN ADC_VOUT ADC_IOUT GH_MON GL_MON BOOT_MON COM
+ PARAMS: FSW=100k DEAD=520n I5CTRL=0.06 I3BIAS=0.005 ETA5=0.85 ETA12=0.85
* Input and power circuit from PDF; R_F1, ESR and diode characteristics assumed.
R_F1 VIN_EXT FUSED 0.02
D1 FUSED V_SHUNT_IN D_SS56_EQ
RS_IN V_SHUNT_IN VIN 0.05
C1 VIN COM 470u IC=0
C2 VIN COM 1u IC=0
XQH VIN G_H SW MOS_SWITCH_EQ
XQL SW G_L COM MOS_SWITCH_EQ
L1 SW L_DCR 220u IC=0
R_L_DCR L_DCR L_RAW 0.15
RS_L L_RAW V_CAP 0.025
C3 V_CAP C3_ESR 470u IC=0
R_C3_ESR C3_ESR COM 0.08
C4 V_CAP COM 10u IC=0
RS_OUT V_CAP VOUT 0.05
R_BL VOUT COM 2.2k
* Equivalent M1/M2/board LDO rails, not actual module regulation models.
VAUX12 DRV12 COM PWL(0 0 0.5m 0 1m 12)
VAUX5 V5 COM PWL(0 0 0.5m 0 1m 5)
V3V3 V3 COM PWL(0 0 0.5m 0 1m 3.3)
GCORE V5 COM VALUE={IF(V(V5)>1,I5CTRL,0)}
GABI V3A COM VALUE={IF(V(V3)>1,I3BIAS,0)}
* Account for 3.3V linear regulator input current at 5V.
GLDO V5 COM VALUE={MAX(0,-I(V3V3))}
GDRVQ DRV12 COM VALUE={IF(V(DRV12)>2,0.001,0)}
* Draw assumed auxiliary INPUT power from VIN: includes gate/rail charging load.
GAUX VIN COM VALUE={IF(V(VIN)>2,(MAX(0,-V(DRV12)*I(VAUX12))/ETA12
+ +MAX(0,-V(V5)*I(VAUX5))/ETA5)/MAX(V(VIN),1),0)}
C5 DRV12 COM 100n IC=0
C6 DRV12 COM 10u IC=0
D_BOOT DRV12 VB D_UF4007_EQ
C_BOOT VB SW 1u IC=0
R_GSH G_H SW 10k
R_GSL G_L COM 10k
RG_H HO G_H 10
RG_L LO G_L 10
* Gate capacitances are SIMULATION assumptions, not additional BOM components.
C_GH_EQ G_H SW 4.7n IC=0
C_GL_EQ G_L COM 4.7n IC=0
* Current sense gains and raw/ADC bandwidth approximations.
R_VDDA V3 V3A 10
C_A1 V3A COM 1u IC=0
C_A2 V3A COM 100n IC=0
C_A3 V3A COM 10u IC=0
E_IIN IIN_IDEAL COM VALUE={LIMIT(20*V(V_SHUNT_IN,VIN),0,V(V3A))}
R_U2 IIN_IDEAL IIN_RAW 1k
C_U2_EQ IIN_RAW COM 400p IC=0
E_IOUT IOUT_IDEAL COM VALUE={LIMIT(20*V(V_CAP,VOUT),0,V(V3A))}
R_U3 IOUT_IDEAL IOUT_RAW 1k
C_U3_EQ IOUT_RAW COM 450p IC=0
E_IL IL_IDEAL COM VALUE={LIMIT(V(V3A)/2+20*V(L_RAW,V_CAP),0,V(V3A))}
R_U4 IL_IDEAL IL_BI 1k
C_U4_EQ IL_BI COM 400p IC=0
R1 VIN_EXT VIN_DIV 100k
R2 VIN_DIV COM 10k
R3 VIN_DIV ADC_VIN 1k
C7 ADC_VIN COM 4.7n IC=0
R4 VOUT VOUT_DIV 10k
R5 VOUT_DIV COM 1k
R6 VOUT_DIV ADC_VOUT 1k
C8 ADC_VOUT COM 4.7n IC=0
R7 IIN_RAW ADC_IIN 1k
C9 ADC_IIN COM 4.7n IC=0
R8 IOUT_RAW ADC_IOUT 1k
C10 ADC_IOUT COM 4.7n IC=0
R_IL_ADC IL_BI ADC_IL 1k
C_IL_ADC ADC_IL COM 4.7n IC=0
* ADC clamps are omitted from this normal-range functional model.
* Reference dividers and raw-signal fault detection from Rev B.
R9 V3A VREF_POS 10k
R10A VREF_POS POS_MID 33k
R10B POS_MID COM 1k
C_REF_POS VREF_POS COM 100n IC=0
R15A V3A NEG_MID 33k
R15B NEG_MID VREF_NEG 1k
R16 VREF_NEG COM 10k
C_REF_NEG VREF_NEG COM 100n IC=0
R11 V3A VREF_OV 23k
R12 VREF_OV COM 10k
C_REF_OV VREF_OV COM 100n IC=0
E_CP CP0 COM VALUE={IF(V(IL_BI)>V(VREF_POS),1,0)}
E_CN CN0 COM VALUE={IF(V(IL_BI)<V(VREF_NEG),1,0)}
E_CO CO0 COM VALUE={IF(V(VOUT_DIV)>V(VREF_OV),1,0)}
R_CP CP0 CP 1k
C_CP CP COM 1.3n IC=0
R_CN CN0 CN 1k
C_CN CN COM 1.3n IC=0
R_CO CO0 CO 1k
C_CO CO COM 1.3n IC=0
S_CP FAULT_N COM CP COM SW_LOGIC
S_CN FAULT_N COM CN COM SW_LOGIC
S_CO FAULT_N COM CO COM SW_LOGIC
R13 V3 FAULT_N 10k
* Functional POR hold: NOT a native HC14/power-ramp model.
VPOR POR COM PWL(0 1 4m 1 4.01m 0)
S_POR FAULT_N COM POR COM SW_LOGIC
* Edge-triggered ARM approximation and reset-dominant analog state storage.
C_ARM ARM ARM_EDGE 1n IC=0
R_ARM ARM_EDGE COM 1k
C_SAFE SAFE COM 10n IC=0
R_SAFE_LEAK SAFE COM 1T
G_SAFE SAFE COM VALUE={IF(V(FAULT_N)<1,V(SAFE)/10,
+ IF(V(ARM_EDGE)>1,(V(SAFE)-3.3)/10,0))}
E_EN EN COM VALUE={IF(V(SAFE)>2,IF(V(MCU_EN)>2,1,0),0)}
* Continuous control proxy, NOT STM32 execution or timer/ADC timing.
VSOFT SOFT COM PWL(0 0 6m 0 16m 1)
VFF FF COM PWL(0 0 6m 0 6.001m 1 15.999m 1 16m 0)
E_EV EV COM VALUE={V(VSET)*V(SOFT)-11*V(ADC_VOUT)}
E_IR IR COM VALUE={LIMIT(0.5*V(EV)+V(XV)+0.048*V(VSET)*V(FF),-0.3,V(ISET))}
C_XV XV COM 1 IC=0
G_XV COM XV VALUE={50*V(EV)+500*(V(IR)-(0.5*V(EV)+V(XV)+0.048*V(VSET)*V(FF)))}
E_ILMEAS IL_MEAS COM VALUE={2*(V(ADC_IL)-V(V3A)/2)}
E_EI EI COM VALUE={V(IR)-V(IL_MEAS)}
E_RAW RAW COM VALUE={V(V_CAP)/MAX(V(VIN),1)+0.15*V(EI)+V(XI)}
E_DUTY DUTY COM VALUE={LIMIT(V(RAW),0.08,0.88)}
C_XI XI COM 1 IC=0
G_XI COM XI VALUE={200*V(EI)+1000*(V(DUTY)-V(RAW))}
* PULSE used as a 0..1V sawtooth; no FLOOR()/ngspice .control syntax.
* 10ns reset plateau avoids a zero-width reset at the period boundary.
VCAR CAR COM PULSE(0 1 0 {1/FSW-20n} 5n 5n {1/FSW})
VSTART START COM PWL(0 0 5.999m 0 6m 1)
E_HCTL HC COM VALUE={IF(V(EN)>0.5,IF(V(START)>0.5,
+ IF(V(VB,SW)>8,IF(V(CAR)>DEAD*FSW,IF(V(CAR)<V(DUTY),1,0),0),0),0),0)}
E_LCTL LC COM VALUE={IF(V(EN)>0.5,IF(V(DRV12)>8,
+ IF(V(START)<0.5,1,IF(V(CAR)>V(DUTY)+DEAD*FSW,1,0)),0),0)}
E_HN HN COM VALUE={1-V(HC)}
E_LN LN COM VALUE={1-V(LC)}
* Driver source/sink impedance assumptions: 50/25 ohm, NOT IR2104 model.
S_HUP VB HO HC COM SW_DRIVE_UP
S_HDN HO SW HN COM SW_DRIVE_DN
S_LUP DRV12 LO LC COM SW_DRIVE_UP
S_LDN LO COM LN COM SW_DRIVE_DN
E_GH_MON GH_MON COM VALUE={V(G_H,SW)}
E_GL_MON GL_MON COM VALUE={V(G_L)}
E_BOOT_MON BOOT_MON COM VALUE={V(VB,SW)}
.MODEL SW_LOGIC SW(RON=5 ROFF=1e12 VT=0.5 VH=0.001)
.MODEL SW_DRIVE_UP SW(RON=50 ROFF=1e10 VT=0.5 VH=0.001)
.MODEL SW_DRIVE_DN SW(RON=25 ROFF=1e10 VT=0.5 VH=0.001)
.MODEL D_SS56_EQ D(IS=2u N=1.4 RS=0.025)
.MODEL D_UF4007_EQ D(IS=5n N=1.5 RS=0.2 TT=75n)
.ENDS GBUCK_REVB_EQ

.SUBCKT MOS_SWITCH_EQ D G S
S_CHANNEL D S G S SW_CHANNEL
D_BODY S D D_BODY_EQ
* Constant parasitic capacitance: permits a defined SW commutation when disabled.
C_DS_EQ D S 250p
.MODEL SW_CHANNEL SW(RON=0.044 ROFF=1e9 VT=6 VH=0.01)
.MODEL D_BODY_EQ D(IS=1n N=1.5 RS=0.03)
.ENDS MOS_SWITCH_EQ
'''

CASES={
 '01_15V_open':dict(vin=15,load=1e12),
 '02_15V_20ohm':dict(vin=15,load=20),
 '03_25V_20ohm':dict(vin=25,load=20),
 '04_25V_8ohm':dict(vin=25,load=8),
 '05_25V_5ohm':dict(vin=25,load=5),
 '06_25V_load_steps':dict(vin=25,load=20,event='load',stop=.16),
 '07_input_15_to_25V':dict(vin=15,load=20,event='line',stop=.12),
 '08_25V_short_test':dict(vin=25,load=8,event='short',stop=.11),
 '09_MCU_disable':dict(vin=25,load=20,event='disable',stop=.12),
}

def make_top(name,vin=25,load=8,event=None,stop=.08):
    vsource='PWL(0 15 80.003m 15 80.013m 25)' if event=='line' else f'DC {vin}'
    en='PWL(0 0 5.1m 0 5.101m 3.3 80.003m 3.3 80.004m 0)' if event=='disable' else 'PWL(0 0 5.1m 0 5.101m 3.3)'
    loads=f'RLOAD VOUT 0 {load:g}\n'
    if event=='load':
        loads='''RLOAD VOUT 0 20
RADD1 VOUT LOAD1 13.3333333333
SADD1 LOAD1 0 LOADCTL1 0 SW_TEST
VLOAD1 LOADCTL1 0 PWL(0 0 80.003m 0 80.004m 1)
RADD2 VOUT LOAD2 13.3333333333
SADD2 LOAD2 0 LOADCTL2 0 SW_TEST
VLOAD2 LOADCTL2 0 PWL(0 0 110.003m 0 110.004m 1)
'''
    if event=='short':
        loads+='''RSHORT VOUT SHORTNODE 0.01
SSHORT SHORTNODE 0 SHORTCTL 0 SW_TEST
VSHORT SHORTCTL 0 PWL(0 0 80.003m 0 80.004m 1)
'''
    return f'''* G problem Rev B / {name} / PSpice-style functional circuit
* 0 = ground. VSET 10V -> CV 10V; ISET 1V -> CC 1A (inductor reference).
* First arm at 5ms; precharge 5.1..6ms; soft start 6..16ms.
VINPUT VIN_EXT 0 {vsource}
VVSET VSET 0 10
VISET ISET 0 1
VARM ARM 0 PULSE(0 3.3 5m 10n 10n 10u 1)
VEN MCU_EN 0 {en}
XBUCK VIN_EXT VOUT VSET ISET ARM MCU_EN FAULT_N IL_BI ADC_IL
+ ADC_VIN ADC_IIN ADC_VOUT ADC_IOUT GH_MON GL_MON BOOT_MON 0 GBUCK_REVB_EQ
{loads}.MODEL SW_TEST SW(RON=1m ROFF=1e12 VT=0.5 VH=0)
{MODEL}
.OPTIONS RELTOL=0.002 ABSTOL=10n VNTOL=1u METHOD=GEAR
.TRAN 100n {stop:g} 0 100n UIC
.PROBE V(VOUT) V(ADC_IOUT) V(IL_BI) V(GH_MON) V(GL_MON) V(BOOT_MON)
.END
'''

def make_import_model():
    """One top-level model for the Multisim component wizard.

    The standalone testbenches retain their original library layout. The wizard
    requires the helper subcircuit to be inside the main subcircuit instead.
    """
    model=MODEL[MODEL.index('.SUBCKT GBUCK_REVB_EQ '):]
    boundary='.ENDS GBUCK_REVB_EQ\n\n'
    assert model.count(boundary)==1
    return model.replace(boundary,'',1)+'.ENDS GBUCK_REVB_EQ\n'


def inspect_model_structure(model):
    """Check the wizard's declaration, nesting and local model requirements."""
    assert model.startswith('.SUBCKT GBUCK_REVB_EQ ')
    stack=[];roots=[];children=[];model_count=0
    for line in model.splitlines():
        fields=line.split()
        if not fields or fields[0].startswith('*'):continue
        directive=fields[0].upper()
        if directive=='.SUBCKT':
            (children if stack else roots).append(fields[1])
            stack.append(fields[1])
        elif directive=='.ENDS':
            assert stack and len(fields)==2 and fields[1]==stack[-1]
            stack.pop()
        elif directive=='.MODEL':
            assert stack,'Dependent .MODEL must be inside the main subcircuit'
            model_count+=1
    assert not stack and roots==['GBUCK_REVB_EQ']
    assert children==['MOS_SWITCH_EQ'] and model_count==7
    # The only declaration-body change is moving the main .ENDS to the end.
    old=MODEL[MODEL.index('.SUBCKT GBUCK_REVB_EQ '):]
    body_lines=lambda text:[s for s in text.splitlines() if s and s!='.ENDS GBUCK_REVB_EQ']
    assert body_lines(model)==body_lines(old)
    return {'top_level_subcircuits':roots,'dependent_subcircuits':children,
            'local_model_definitions':model_count,'only_outer_ends_relocated':True}


def main():
    (ROOT/'models').mkdir(exist_ok=True)
    (ROOT/'circuits').mkdir(exist_ok=True)
    # Leave embedded testbench MODEL unchanged to preserve existing provenance.
    import_model=make_import_model()
    inspect_model_structure(import_model)
    for extension in ['lib','cir','txt']:
        (ROOT/'models'/f'G_BUCK_RevB_EQ.{extension}').write_text(import_model,encoding='ascii')
    for name,kw in CASES.items():
        (ROOT/'circuits'/f'{name}.cir').write_text(make_top(name,**kw),encoding='ascii')
    print('Generated 9 complete test circuits and identical .lib/.cir/.txt model copies.')

if __name__=='__main__':main()
