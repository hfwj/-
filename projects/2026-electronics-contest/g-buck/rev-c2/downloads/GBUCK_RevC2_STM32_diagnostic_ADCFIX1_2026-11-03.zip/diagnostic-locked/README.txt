ADCFIX1 / A1, 2026-11-03. POWER=0, KEYS=0, LCD=1.
No power-stage enable is possible in this delivered build.
Flash diagnostic-locked/gbuck.hex at its embedded address (BIN: 0x08000000), with verification.
The ADC SMPR2 correction is compiled and host-tested, NOT hardware-verified.
Do not reuse the old 0x2000007C command address.
For this exact image: debug_command=0x2000009C; raw[6]=0x20000024, 32 bits per channel.
See firmware/docs/ADC采样修正与上板复测_2026-11-03.md and build_manifest.json.
