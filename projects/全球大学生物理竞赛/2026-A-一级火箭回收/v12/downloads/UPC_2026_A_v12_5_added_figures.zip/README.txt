Five added original scientific figures: mission/geometry (Fig 1), workflow (Fig 2), passive diagnostics (Fig 3), throttle response (Fig 4), and sensitivity (Fig 7).
Geometry is illustrative; M1 remains unsolved. Sensitivity shows the terminal window of actual frozen-plan replays, not a closed-loop failure probability. Full histories and data are in the main reproduction bundle.
